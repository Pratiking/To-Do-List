document.addEventListener('DOMContentLoaded', () => {
    const newTaskInput = document.getElementById('new-task-input');
    const addTaskBtn = document.getElementById('add-task-btn');
    const pendingTasksList = document.getElementById('pending-tasks-list');
    const completedTasksList = document.getElementById('completed-tasks-list');
    const themeToggleBtn = document.getElementById('theme-toggle-btn');

    let tasks = [];

    function saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function loadTasks() {
        const savedTasks = localStorage.getItem('tasks');
        if (savedTasks) {
            tasks = JSON.parse(savedTasks);
        }
    }

    function renderTasks() {
        pendingTasksList.innerHTML = '';
        completedTasksList.innerHTML = '';

        tasks.forEach(task => {
            const li = document.createElement('li');
            li.className = 'task-item';
            if (task.completed) {
                li.classList.add('completed');
            }

            const taskInfo = document.createElement('div');
            taskInfo.className = 'task-info';

            const taskText = document.createElement('p');
            taskText.className = 'task-text';
            taskText.textContent = task.text;

            const taskDatetime = document.createElement('p');
            taskDatetime.className = 'task-datetime';
            if (task.completed) {
                taskDatetime.textContent = `Completed: ${new Date(task.completedAt).toLocaleString()}`;
            } else {
                taskDatetime.textContent = `Added: ${new Date(task.addedAt).toLocaleString()}`;
            }

            taskInfo.appendChild(taskText);
            taskInfo.appendChild(taskDatetime);

            li.appendChild(taskInfo);

            const actions = document.createElement('div');
            actions.className = 'task-actions';

            // Edit button
            const editBtn = document.createElement('button');
            editBtn.innerHTML = '✏️';
            editBtn.title = 'Edit task';
            editBtn.addEventListener('click', () => {
                if (li.querySelector('.edit-input')) {
                    return; // already editing
                }
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'edit-input';
                input.value = task.text;
                taskInfo.replaceChild(input, taskText);
                input.focus();

                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') {
                        const newText = input.value.trim();
                        if (newText) {
                            task.text = newText;
                            saveTasks();
                            renderTasks();
                        }
                    } else if (e.key === 'Escape') {
                        renderTasks();
                    }
                });

                input.addEventListener('blur', () => {
                    renderTasks();
                });
            });
            actions.appendChild(editBtn);

            // Complete button (only for pending tasks)
            if (!task.completed) {
                const completeBtn = document.createElement('button');
                completeBtn.innerHTML = '✔️';
                completeBtn.title = 'Mark as complete';
                completeBtn.addEventListener('click', () => {
                    task.completed = true;
                    task.completedAt = new Date().toISOString();
                    saveTasks();
                    renderTasks();
                });
                actions.appendChild(completeBtn);
            }

            // Delete button
            const deleteBtn = document.createElement('button');
            deleteBtn.innerHTML = '🗑️';
            deleteBtn.title = 'Delete task';
            deleteBtn.addEventListener('click', () => {
                tasks = tasks.filter(t => t !== task);
                saveTasks();
                renderTasks();
            });
            actions.appendChild(deleteBtn);

            li.appendChild(actions);

            if (task.completed) {
                completedTasksList.appendChild(li);
            } else {
                pendingTasksList.appendChild(li);
            }
        });
    }

    addTaskBtn.addEventListener('click', () => {
        const text = newTaskInput.value.trim();
        if (text) {
            const newTask = {
                text,
                addedAt: new Date().toISOString(),
                completed: false,
                completedAt: null
            };
            tasks.push(newTask);
            saveTasks();
            renderTasks();
            newTaskInput.value = '';
            newTaskInput.focus();
        }
    });

    newTaskInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            addTaskBtn.click();
        }
    });

    // Theme toggle logic
    function setTheme(theme) {
        if (theme === 'dark') {
            document.body.classList.add('dark-theme');
            themeToggleBtn.textContent = '☀️';
        } else {
            document.body.classList.remove('dark-theme');
            themeToggleBtn.textContent = '🌙';
        }
        localStorage.setItem('theme', theme);
    }

    themeToggleBtn.addEventListener('click', () => {
        const currentTheme = document.body.classList.contains('dark-theme') ? 'dark' : 'light';
        if (currentTheme === 'dark') {
            setTheme('light');
        } else {
            setTheme('dark');
        }
    });

    // Load theme from localStorage
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);

    loadTasks();
    renderTasks();
});
